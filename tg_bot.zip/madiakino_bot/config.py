﻿#By @K1p1k#
#Downloaded from TG @KiTools#
#Leave this inscription#

token='5941289653:AAEd1RleNaILqqe7TeNE0JIJZPqnzZwB3As' #https://t.me/BotFather
admin_id=[5891335753] #https://t.me/getidsbot #водить через запетую если не сколько [12321, 3139231]
rate_searsh=10

#Автор: @K1p1k#
#Загружено с TG @KiTools#
#Оставь эту надпись#
