#by @K1p1k#
#Downloaded from TG @KiTools#
#Leave this inscription#

from aiogram.dispatcher.filters.state import State, StatesGroup

class User_State(StatesGroup):
    class search_film(StatesGroup):
        text=State()

#Автор: @K1p1k#
#Загружено с TG @KiTools#
#Оставь эту надпись#