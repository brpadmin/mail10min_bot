API_TOKEN = '6028739628:AAGp75AHTTW2jxDP61pNm2aGwi9vRS04p9Q' # токен от тлеграм бота
admin = 5891335753 # id админа, тобиж твой (взять тут - t.me/userinfobot)
